"use strict";
try {
  importScripts("service/background.js");
} catch (e) {
  console.error(e);
}
